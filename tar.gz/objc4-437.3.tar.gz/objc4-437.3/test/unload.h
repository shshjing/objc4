@interface SmallClass { id isa; } 
+(id)new;
-(void)free;
@end

@interface BigClass { id isa; } 
+(id)new;
-(void)free;
@end

