#include "future.h"

@implementation Super 
+class { return self; } 
+(void)initialize { } 
@end

